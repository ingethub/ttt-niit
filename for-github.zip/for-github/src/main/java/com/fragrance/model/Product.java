package com.networkdevices.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product {
	@Id
	private int PID;
	private String PDESC;
	private String PRICE;
	private String PNAME; 
	private String URL; 
	
	public Product(){}
	public Product(int pID, String pDESC, String pRICE, String pNAME, String uRL) {
		super();
		PID = pID;
		PDESC = pDESC;
		PRICE = pRICE;
		PNAME = pNAME;
		URL = uRL;
	}
	public int getPID() {
		return PID;
	}
	public void setPID(int pID) {
		PID = pID;
	}
	public String getPDESC() {
		return PDESC;
	}
	public void setPDESC(String pDESC) {
		PDESC = pDESC;
	}
	public String getPRICE() {
		return PRICE;
	}
	public void setPRICE(String pRICE) {
		PRICE = pRICE;
	}
	public String getPNAME() {
		return PNAME;
	}
	public void setPNAME(String pNAME) {
		PNAME = pNAME;
	}
	public String getURL() {
		return URL;
	}
	public void setURL(String uRL) {
		URL = uRL;
	}

}
