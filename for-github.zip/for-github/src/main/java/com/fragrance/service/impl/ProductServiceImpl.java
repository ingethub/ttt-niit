package com.networkdevices.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.networkdevices.DAO.ProductDAO;
import com.networkdevices.model.Product;
import com.networkdevices.service.ProductService;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDAO productData;
	
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub		
		return productData.getAllProducts();
		//return null;
	}

	public Product getProduct(int pid) {
		// TODO Auto-generated method stub
		return productData.getProduct(pid);
		
	}

	public String editProduct(Product p) {
		// TODO Auto-generated method stub
	//	return null;
		return productData.editProduct(p);
	}

	public String delProduct(int pid) {
		// TODO Auto-generated method stub
		return productData.delProduct(pid);		
	}

	public int addProduct(Product p) {
		// TODO Auto-generated method stub
		return productData.addProduct(p);
	}

}
