package com.networkdevices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.networkdevices.DAO.ProductDAO;
import com.networkdevices.DAO.impl.ProductDAOImpl;
import com.networkdevices.model.Product;
import com.networkdevices.service.ProductService;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
//import com.networkdevices.DAO.NetworkDeviceDAO;//.NetworkDeviceDAO;

@Controller
public class NetworkDevicesController {

	
	@Autowired	
	public ProductService prodserv;
	
	// global
	//List<NetworkDeviceModel> list=null;
	String setName = "";
	ProductDAO ndd = null;

	@RequestMapping("/login")
	public ModelAndView getLog() {
		ModelAndView mv=new ModelAndView("login");
		return mv;
	}	
	


	@RequestMapping("/authenticate")
	public ModelAndView authenticate(@RequestParam (value="una",required=false,defaultValue="") String uname,
			@RequestParam(value="pwd", required=false,defaultValue="") String pass)
	{
		ModelAndView mv=null;
		String u,p;
		u="NIIT";
		p="niit";
		if(u.equals(uname) && p.equals(pass))
		{			
		mv = new ModelAndView("success");
		mv.addObject("una",uname);
		}
		else {
			mv=new ModelAndView("loginerror");			
		}			
		//System.out.println("HHHHHHHHHHHHHHHHHHHHHHHH");
		return mv;
	}	
	
	
	

	@RequestMapping("/registration")
	public ModelAndView getReg() {
		ModelAndView mv = new ModelAndView("registration");
		return mv;
	}



	@RequestMapping("/device")
	public ModelAndView AllProductCode(
			@RequestParam(value = "name", required = false, defaultValue = "DEVICE") String name) {
		ModelAndView allprod = new ModelAndView("alldeviceinfo");
		setName = name;
		System.out.println(setName);
		return allprod;
	}

	@RequestMapping("/GsonCon")
	public @ResponseBody String getValues() {
			
		ndd = new ProductDAOImpl();
		String devs="";
		List <Product> one_dev=new ArrayList<Product>();
		Product d = null;
		if("alldev".equals(setName)){
			System.out.println("gson all products...");
			List <Product> listdev = prodserv.getAllProducts();
			Gson gson = new Gson();
			devs=gson.toJson(listdev);
		}
		else{		
			System.out.println("gson one product...");
			int i = Integer.parseInt(setName);
			Product nd = prodserv.getProduct(i);
			List <Product> ld = new ArrayList<Product>();
			ld.add(nd);
			Gson gson=new Gson();
			devs=gson.toJson(ld);				
		}
		return devs;
		
			
		/*
		  NetworkDeviceDAO dao = new NetworkDeviceDAO();

		if (setName.equals("rtr2") || setName.equals("ssw2") || setName.equals("wifi2")) {
			list = dao.getDevice(setName);
		}
		if (setName.equals("alldev")) {
			list = dao.getAllDevices();
		}
		*/
		/*
		if (setName.equals("alldev")) {
			list = dao.getAllDevices();
		}
		else {
			list = dao.getDevice(setName);
		}
		System.out.println(setName);
		// list= dao.getAllProducts();
		Gson gson = new Gson();
		//String result = gson.toJson(list);
		return null;
		*/
		
	}
	
	/*	
    @RequestMapping(value="/remove/{pid}", method=RequestMethod.GET)
    public ModelAndView removeOrganization(@PathVariable Integer pid) {
        ModelAndView modelAndView = new ModelAndView("confirm");
       prodserv.delProduct(pid);
        
        String  message = "Fragrance product was successfully deleted.";
        modelAndView.addObject("message", message);
        System.out.println("remove mapped");
        return modelAndView;
	}
	*/
	
	@RequestMapping("/remove")
	public ModelAndView getDelProd(@RequestParam(value="id", required=false,defaultValue="") int nnn)
	{
		System.out.println("Deletes..............................");
		ModelAndView mv=new ModelAndView("alldeviceinfo");
		//int pid=Integer.parseInt(nnn);
		String f1=prodserv.delProduct(nnn);
		
		return mv;
	}

	/*
	 * @RequestMapping("/product") public ModelAndView img1(@RequestParam
	 * (value="name",required=false,defaultValue="img") String name) {
	 * ModelAndView mv = null;
	 * 
	 * if("img4".equals(name)){ mv = new ModelAndView("productDetails");
	 * mv.addObject("pid","101"); mv.addObject("pname","Music");
	 * mv.addObject("pdesc","play music"); mv.addObject("pprice","50"); return;
	 * mv; } if("img5".equals(name)){ mv = new ModelAndView("productDetails");
	 * mv.addObject("pid","102"); mv.addObject("pname","Music");
	 * mv.addObject("pdesc","Heart music"); mv.addObject("pprice","100"); return
	 * mv; } if("img6".equals(name)){ mv = new ModelAndView("productDetails");
	 * mv.addObject("pid","103"); mv.addObject("pname","Music");
	 * mv.addObject("pdesc","playing music"); mv.addObject("pprice","100");
	 * return mv; } if("allprod".equals(name)){ mv = new
	 * ModelAndView("GsonConvert"); return mv; } return mv; }
	 */
}
