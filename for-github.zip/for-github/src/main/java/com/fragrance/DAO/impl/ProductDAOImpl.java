package com.networkdevices.DAO.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.networkdevices.DAO.ProductDAO;

import com.networkdevices.model.Product;

public class ProductDAOImpl implements ProductDAO {

	List <Product> lst = new ArrayList<Product>();
	
	Product productData;
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public ProductDAOImpl(){}
	
	
	public void setSessionFactory(SessionFactory sessionFactory){
		this.sessionFactory=sessionFactory;
	}
	public Session getCurrentSession(){
		return sessionFactory.getCurrentSession();
	}
	
	

	public int addProduct(Product p) {
		// TODO Auto-generated method stub	
		
		Session session = sessionFactory.openSession();
		Transaction tx = (Transaction)session.beginTransaction();
		System.out.println("After current");
		session.save(p);
		tx.commit();
		Serializable id = session.getIdentifier(p);
		session.close();
		return (Integer)id;	  
		
	}
	
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		List<Product> lst;
		System.out.println("getAllDevices()");
		Session ses = sessionFactory.openSession();
		System.out.println("getAllDevices()session " + ses.isOpen());
		Query qry = ses.createQuery("from Product");
		lst = qry.list();
		System.out.println(lst);
		return lst;
	}

	public Product getProduct(int pid) {
		// TODO Auto-generated method stub
		Session ses=sessionFactory.openSession();
		productData = (Product)ses.get(Product.class,pid);
		return productData;				
		//return null;
	}

	public String editProduct(Product p) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction tx = (Transaction)session.beginTransaction();
		System.out.println("editDevice()");
		session.saveOrUpdate(p);
		tx.commit();
		Serializable id = session.getIdentifier(p);
		session.close();
		return (String)id;
	}

	public String delProduct(int pid) {
/* * 		
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction tx = (Transaction)session.beginTransaction();
		Product ndm = (Product)session.load(Product.class, pid);
		session.delete(ndm);
		Serializable ids = session.getIdentifier(ndm);
		session.close();
		return (String)ids;			
 	*/
		Transaction tx = null;
		Product prd = getProduct(pid);
		try {
				tx = sessionFactory.getCurrentSession().beginTransaction();
				sessionFactory.getCurrentSession().delete(prd);
				tx.commit();
		}
		catch (HibernateException e) {
			if (tx != null) tx.rollback();
			e.printStackTrace();		
		}
		return "";
	}
}
