package com.networkdevices.DAO;

import java.util.List;


import com.networkdevices.model.Product;

public interface ProductDAO {  
	public List<Product> getAllProducts();  
	public Product getProduct(int pid);
	public String editProduct(Product p);
	public String delProduct(int pid);
	public int addProduct(Product p);  
}
